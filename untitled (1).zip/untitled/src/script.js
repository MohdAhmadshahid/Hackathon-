// -------- Service Data (Simulated Backend) --------
const services = [
  {
    id: 1,
    name: "Bright Spark Electricals",
    category: "Electrician",
    location: "Andheri",
    availability: "Available",
    rating: 4.6 
  },
  {
    id: 2,
    name: "Glowup  Electricals",
    category: "Electrician",
    location: "Andheri",
    availability: "Not Available",
    rating: 5 
  },
  {
    id: 3,
    name: "Sparks Electricals",
    category: "Electrician",
    location: "Bandra",
    availability: "Available",
    rating: 2.6 
  },
  {
    id: 4,
    name: "Mega Glow Electricals",
    category: "Electrician",
    location: "Bandra",
    availability: "Not Available",
    rating: 4.9 
  },
  {
    id: 5,
    name: "Lightup Electricals",
    category: "Electrician",
    location: "Dadar",
    availability: "Available",
    rating: 2.6 
  },
  {
    id: 6,
    name: "PipefitPlumbing",
    category: "Plumber",
    location: "Bandra",
    availability: "Busy",
    rating: 4.1
  },
   {
    id: 7,
    name: "HitfitPlumbing",
    category: "Plumber",
    location: "Bandra",
    availability: "Available",
    rating: 3
  },
   {
    id: 6,
    name: "Quickfix Plumbing",
    category: "Plumber",
    location: "Dadar",
    availability: "Busy",
    rating: 4
  },
  {
    id: 7,
    name: "TiteBond  Plumbing",
    category: "Plumber",
    location: "Dadar",
    availability: "Available",
    rating: 2.6
  },
  {
    id: 8,
    name: "Watersaver Plumbing",
    category: "Plumber",
    location: "Andheri",
    availability: "Busy",
    rating: 5
  },
   {
    id: 9,
    name: "Water Plumbing",
    category: "Plumber",
    location: "Andheri",
    availability: "Available",
    rating: 4
  },
  {
    id: 10,
    name: "Smart Home Tutors",
    category: "Tutor",
    location: "Dadar",
    availability: "Offline",
    rating: 4.8
  },
  {
    id: 11,
    name: "Home Tutors",
    category: "Tutor",
    location: "Dadar",
    availability: "Online",
    rating: 4
  },
   {
    id: 12,
    name: "Learn With Fun Tutors",
    category: "Tutor",
    location: "Andheri",
    availability: "Offline",
    rating: 5
  },
   {
    id: 13,
    name: "Two Tutors",
    category: "Tutor",
    location: "Andheri",
    availability: "Online",
    rating: 4.9
  },
   {
    id: 14,
    name: "T for Tutors",
    category: "Tutor",
    location: "Bandra",
    availability: "Online",
    rating: 3.9
  },
   {
    id: 15,
    name: "Whom to Home Tutors",
    category: "Tutor",
    location: "Bandra",
    availability: "Offline",
    rating: 3
  }
];

// -------- App Logic --------
const container = document.getElementById("serviceContainer");
const categoryFilter = document.getElementById("categoryFilter");
const locationFilter = document.getElementById("locationFilter");
const availabilityFilter = document.getElementById("availabilityFilter");
const searchInput = document.getElementById("searchInput");

// Loading State
container.innerHTML = "<p style='text-align:center'>Loading services...</p>";

setTimeout(() => {
  renderServices(services);
}, 800);

function renderServices(data) {
  container.innerHTML = "";

  if (data.length === 0) {
    container.innerHTML = "<p style='text-align:center'>No services found</p>";
    return;
  }

  data.forEach(service => {
    const card = document.createElement("div");
    card.className = "service-card";

    card.innerHTML = `
      <h3>${service.name}</h3>
      <p><strong>Category:</strong> ${service.category}</p>
      <p><strong>Location:</strong> ${service.location}</p>
      <p><strong>Status:</strong> ${service.availability}</p>
      <p>⭐ ${service.rating}</p>
    `;

    container.appendChild(card);
  });
}

function applyFilters() {
  let filtered = services;

  if (categoryFilter.value)
    filtered = filtered.filter(s => s.category === categoryFilter.value);

  if (locationFilter.value)
    filtered = filtered.filter(s => s.location === locationFilter.value);

  if (availabilityFilter.value)
    filtered = filtered.filter(s => s.availability === availabilityFilter.value);

  renderServices(filtered);
}

categoryFilter.addEventListener("change", applyFilters);
locationFilter.addEventListener("change", applyFilters);
availabilityFilter.addEventListener("change", applyFilters);

searchInput.addEventListener("input", () => {
  const text = searchInput.value.toLowerCase();
  const filtered = services.filter(s =>
    s.name.toLowerCase().includes(text) ||
    s.category.toLowerCase().includes(text)
  );
  renderServices(filtered);
});

